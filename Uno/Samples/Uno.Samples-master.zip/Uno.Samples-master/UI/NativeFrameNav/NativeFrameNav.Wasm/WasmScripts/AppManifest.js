var UnoAppManifest = {

    splashScreenImage: "Assets/SplashScreen.png",
    splashScreenColor: "#0078D7",
    displayName: "NativeFrameNav"

}
