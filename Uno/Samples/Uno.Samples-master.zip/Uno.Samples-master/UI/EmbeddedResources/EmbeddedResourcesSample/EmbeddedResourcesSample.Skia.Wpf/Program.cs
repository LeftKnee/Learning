﻿
namespace EmbeddedResourcesSample.Skia.Gtk
{
}
