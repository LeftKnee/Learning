# Android Custom Camera Activity Sample

This sample is android specific, and show how to start a camera capture 
intent, and display the result in an `Image` control.
