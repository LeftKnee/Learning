﻿var UnoAppManifest = {

    splashScreenImage: "Assets/SplashScreen.scale-200.png",
    splashScreenColor: "#00f",
    displayName: "CameraCaptureUISample"

}
