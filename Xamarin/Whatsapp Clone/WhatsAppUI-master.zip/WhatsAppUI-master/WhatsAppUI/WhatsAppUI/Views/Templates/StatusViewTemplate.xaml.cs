﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace WhatsApp.Views.Templates
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class StatusViewTemplate : ContentView
    {
        public StatusViewTemplate()
        {
            InitializeComponent();
        }
    }
}