using AppKit;
using Foundation;

namespace StatusBarColorSample.macOS
{

}
