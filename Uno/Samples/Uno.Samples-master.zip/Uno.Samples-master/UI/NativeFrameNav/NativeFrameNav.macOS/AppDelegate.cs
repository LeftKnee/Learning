using AppKit;
using Foundation;

namespace NativeFrameNav.macOS
{

}
