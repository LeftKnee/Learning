# Benchmark.NET Sample (Works on Wasm only)

This is a simple standalone app that demonstrates the use of Benchmark.NET with the Uno platform.

This application uses a [custom build of Benchmark.NET](https://github.com/unoplatform/Uno.BenchmarkDotNet) that runs on WebAssembly.