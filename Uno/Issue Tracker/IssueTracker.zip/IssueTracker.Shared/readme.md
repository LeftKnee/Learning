﻿# Unosoft Technologies - Issue Tracker

## Known Issues

- Back button is missing from Chrome, and macOS. This issue was logged on the Uno Platform Github Issues section [here](https://github.com/unoplatform/uno/issues/3459)