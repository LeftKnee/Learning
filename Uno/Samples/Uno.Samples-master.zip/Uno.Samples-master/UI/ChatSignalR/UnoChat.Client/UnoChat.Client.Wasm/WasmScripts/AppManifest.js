﻿var UnoAppManifest = {

    splashScreenImage: "Assets/SplashScreen.scale-200.png",
    splashScreenColor: "#FFFFFF",
    displayName: "UnoChat"

}
