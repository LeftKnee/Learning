﻿namespace IssueTracker.Models
{
    public enum IssueStatus
    {
        Planned,
        Started,
        Completed
    }
}
