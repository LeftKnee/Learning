﻿namespace IssueTracker.Models
{
    public enum IssueType
    {
        Bug,
        Task,
        Feature
    }
}
